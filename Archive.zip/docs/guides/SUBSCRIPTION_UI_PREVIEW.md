# Subscription Info UI Preview

## Visual Examples

### 1. Active Subscription (Collapsed View)
```
┌─────────────────────────────────────────────────────────────┐
│ 📋  Subscription Status                          ▼ Details  │
│     [Active] [Paid]                                         │
│     Valid until December 15, 2025                           │
└─────────────────────────────────────────────────────────────┘
```

### 2. Active Subscription (Expanded View)
```
┌─────────────────────────────────────────────────────────────┐
│ 📋  Subscription Status                          ▲ Hide     │
│     [Active] [Paid]                                         │
│                                                              │
│ ─────────────────────────────────────────────────────────── │
│                                                              │
│ Start Date          End Date           Amount               │
│ Jan 15, 2025        Dec 15, 2025       PKR 12,000          │
└─────────────────────────────────────────────────────────────┘
```

### 3. Expiring Soon (Collapsed View)
```
┌─────────────────────────────────────────────────────────────┐
│ 📋  Subscription Status                          ▼ Details  │
│     [Active] [Pending]                                      │
│     ⏰ Expires in 25 days                                   │
└─────────────────────────────────────────────────────────────┘
```
*Yellow/Orange background*

### 4. Expired Subscription (Collapsed View)
```
┌─────────────────────────────────────────────────────────────┐
│ 📋  Subscription Status                          ▼ Details  │
│     [Expired] [Overdue]                                     │
│     ⚠️ Subscription expired                                 │
└─────────────────────────────────────────────────────────────┘
```
*Red background*

## Color Scheme

### Status Badges
- **Active:** Green background (#dcfce7), Green text (#166534)
- **Expired:** Yellow background (#fef9c3), Yellow text (#854d0e)
- **Cancelled:** Red background (#fee2e2), Red text (#991b1b)

### Payment Status Badges
- **Paid:** Green background (#dcfce7), Green text (#166534)
- **Pending:** Yellow background (#fef9c3), Yellow text (#854d0e)
- **Overdue:** Red background (#fee2e2), Red text (#991b1b)

### Card Backgrounds
- **Active (Not Expiring):** Light green (#f0fdf4) with green border
- **Expiring Soon:** Light yellow (#fefce8) with yellow border
- **Expired:** Light red (#fef2f2) with red border

## Placement

### Dashboard
```
┌─────────────────────────────────────────────────────────────┐
│ Welcome back, John Doe!                                     │
│ Here's what's happening with your business today.          │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ 📋  Subscription Status                          ▼ Details  │
│     [Active] [Paid]                                         │
│     Valid until December 15, 2025                           │
└─────────────────────────────────────────────────────────────┘

┌──────────┬──────────┬──────────┬──────────┐
│ Total    │ Low      │ Total    │ Pending  │
│ Products │ Stock    │ Customers│ Invoices │
│ 150      │ 5        │ 45       │ 12       │
└──────────┴──────────┴──────────┴──────────┘
```

### Settings Page
```
┌─────────────────────────────────────────────────────────────┐
│ Settings                                                    │
│ Manage your company settings and preferences               │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ 📋  Subscription Status                          ▼ Details  │
│     [Active] [Paid]                                         │
│     Valid until December 15, 2025                           │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ [Company] [Invoice] [Templates] [Email] [WhatsApp] [FBR]   │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│ Company Information                                         │
│ ...                                                          │
└─────────────────────────────────────────────────────────────┘
```

## Responsive Behavior

### Desktop (≥768px)
- Full width with 3-column grid in expanded view
- All information visible side by side

### Mobile (<768px)
- Full width
- Single column layout in expanded view
- Stacked information
- Touch-friendly expand/collapse button

## Interaction States

### Hover
- Expand/collapse button changes color
- Subtle shadow increase on card

### Click
- Smooth expand/collapse animation
- Button text changes (▼ Details ↔ ▲ Hide)

### Loading
- Component doesn't render until data is loaded
- No loading spinner (silent loading)

## Accessibility

- Semantic HTML structure
- Color contrast meets WCAG AA standards
- Keyboard navigable
- Screen reader friendly labels
- Focus indicators on interactive elements

## No Subscription State
When a company has no subscription:
- Component doesn't render at all
- No empty state message
- No visual clutter
- Dashboard/Settings appear normal

This creates a clean experience where subscription info only appears when relevant.
