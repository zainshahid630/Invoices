
ew!** 🎉viprelive with mplete now cobuilder is r template ---

**Youate

 Save templd
6.ede ne asRepeatreview
5. Close to p4. fields
le re
3. Toggnfigu co2. Click to elements
**
1. Addrkflow:iew

**WoPrevcted → Live eleen nothing sation
- Whd Configurted → Fielec element selWhen:** 
- ight Sidebarfigure)
**Ronlick to cs (cle:** CanvaddMiows
**Elements & R* r:*eft Sideba-pro`

**Llate-builderemp**URL:** `/t

ReferenceQuick ---

## 📞 ombined

d control ciel- Grid + f** le Layouts**Flexibmation
✅ fory innnecessar Hide uol** -nal Contrssioy
✅ **Profestantllts inresufields, see - Toggle eration** *Fast Itrint
✅ *at you pe is whse - What you es**rpris**No Sut
✅ outpus exact eview showet** - Pr What You G*See

✅ *efitsen

## 🚀 B-lds!

--or wBest of bothnt
- for conteields gure f Confiut
- layoore rows f- Us
l**s = Powerfu Field
✅ **Grid +preview
 best in at lookswhs
- See field different Try hidingions**
- nt Combinat Differe

✅ **Teste all fields- Disabltton one" bu- "✕ Nll fields
 - Enable auttonl" b- "✓ Al
s**uick Toggle **Use Qew

✅ see previurator toose config
- Then clieldsour fup all yet - Sr**
Afteew viFirst, Pre**Configure 
✅ Tips


## 💡 Pro 

---e formatatnt ds: Curre Dateunts
-ulated amootals: Calcs
- Tricewith pB" duct  A", "Pros: "ProductItem
- d"Ltess omer Busin", "Custmer NametoBuyer: "Cus"
- me Ltd"Business Na", y Name"Compan
- Company: ta Shown:Da## Sample 

#acing), spers, colorsting** (bordl format**Reaize
- al to visu**e data
- **Samplre shown fields** atedlecnly se*Ows
- *our grid/rowith yut** t layoExac
- **ee:at You S
### Wh
Featuresew 🎨 Previ
---

## ce Number
 ☑/☐ Invoice Title
-- ☑/☐ Invoir
ade### Het

oun/☐ Total Amer Tax
- ☑/☐ Furth- ☑ax
 T☑/☐ SalesSubtotal
- 
- ☑/☐ s# Total##otal

☐ Line T ☑/ty
-nti Qua ☑/☐Price
-nit 
- ☑/☐ U
- ☑/☐ UOMHS Code- ☑/☐ 
m Name☑/☐ Ite
- ms Table## Ite

#tatus☐ Payment Se Type
- ☑/☑/☐ Invoicber
- PO Num/☐ e Date
- ☑ ☑/☐ Invoic Number
-nvoice
- ☑/☐ Ilsice Detai Invo

###ProvinceCNIC
- ☑/☐ NTN/ess
- ☑/☐  ☑/☐ Addrss Name
-sine Bu
- ☑/☐yer Name- ☑/☐ Buuyer Info


### Bl/☐ Emai☐ Phone
- ☑- ☑/
☐ GST Number- ☑/ber
NumNTN ☐ dress
- ☑/me
- ☑/☐ AdNa/☐ Business  Name
- ☑nyCompa☐ y Info
- ☑/ompan## Cons

#uration Optionfig 📊 Field C
---

##ady!
 is replateem   - Your t" button
ve Templateick "Sa**
   - Clve Template. **Saew

5ges in previSee chands
   - le more fiele
   - Toggurfigin to reconent aga- Click elem
   ded**t as Nee
4. **Adjusespected
 are rttingsfield sek
   - All ill looce woiinvhow ee exactly iew
   - S prevr shows livebaRight side   - s selected
ment ile When no eork**
   -r Wew Youevi

3. **Preo closClick ✕ t - /off
  le fields on
   - Toggcheckboxeseld ws fishoidebar   - Right s
 sent on canvaemck el
   - Clint**ch ElemeEa**Configure s

2. ayoutgrid ld rows for - Or ad   r
t sidebaefrom l elements fick   - ClElements**
 **Add e

1.mplatur Teng Youildi

### Bte Workflow# 🎯 Comple

#
---
```
otals only tselectedeview shows 
4. Prl Amount ☑ Tota
  r Tax Furthe ☐ Tax
  alestal
   ☑ S ☑ Subto
   show:t to whahooseigure
3. C confck it to. Cli
2ment" ele"Totals
1. Add 
```als Section. Custom Tot```

### 4
fied tablemplihows si s Previewotal
4.
   ☑ Line TytitM
   ☑ Quan☐ UOS Code
    Hame
   ☐  ☑ Item Np only:
 . Keefigure
3o conit tt
2. Click men" eles Tabledd "Item``
1. Able
`s Tal Item3. Minima## e
```

#atand dce #  only invoi showsewus
4. Previent StatPaym
   ☐    ☐ Type PO Number
ate
   ☐ber
   ☑ Doice Num Invy:
   ☑ onlKeep3. figure
it to conk . Clict
2s" elemenilice Deta"Invo
1. Add s
```voice Detailal Iny EssentiOnl. Show `

### 2address
``fo WITHOUT uyer in beview shows5. Prnfigurator
ose coess"
4. Clheck "Addr
3. Unconfigureto click it t
2. Co" elemenBuyer Inf
1. Add "
```ddressyer Aide Bu
### 1. H
CasesUse 

## 💡 

---`──┘
``─────────────────────────────────────────────────── │
└─────────┘ ─────────└──────  ───────────┘─┘  └─────
│  └─────  │    │!)  Code  (No HS        │  │    │         │   │  │  │
│─┘  ────────────  │  │  └─       │  │             │  │
│  │ | 5     │ od  │ Pr      │  │  │       │         │     │  │  │
│| Qty Item     │  │  │        │  │    │         │  │
│  ──────┐│  ┌────────│         │             │ │
│  │    review   │ Live P│  👁️ │          │            │    │
│  │lected:  │  n Desehe   │  │  W         │  │   
│  │           │  │                 │  │        │  │       │       
│        │  │M        │  │  ☑ UO             │  │    │       │
│ │Code        HS   │  ☐  │               │  │  │       │  │
│  ame     N│  ☑ Item      │       │  │            │
│  │ure      │ ️ Config  │  │  ⚙k   ↓ Clice  │  │ │  │  Tabl:    │  │
n Selected Whebl] │  │   │ [Items Tms ││  │📊 Ite │  │
             │  │                    │  │   
│  │     r     │  │debaight Si Rvas    │  │  │  │   Can│  │Elements┐  │
─────────── ┌───────────────┐ ────────────┐  ┌
│  ┌────   │                               ro r Pe Builde
│  Templat───┐──────────────────────────────────────────────────────``
┌
`
owual Fl## 🎨 Vis
---

nstead
e iS Code ther H
- Show tablent above the text elemey**
- Add ade Separatel Co: Add HSStep 4le!**

**m the tab gone fromn isode colu
- **HS Cewlive previows r now sh sidebaightgurator
- Ronfiose field cthe ✕ to clk ew**
- Clicreviee Live P*Step 3: S
*  ```
 Total
 Line ☑tity
 uanPrice
  ☑ Q Unit  ☑
  ☑ UOMk this
 chec   ← Un     Code  ☐ HSm Name
  Ite```
  ☑xes:
  d checkbohows fiel sht sidebar- Rigelement
Table tems ck the Ilids**
- Cure Fiel 2: Config

**Stepon canvass nt appearr
- Elemeeft sideba lle" from "Items Tab- Click*
ems Table*ep 1: Add Itble

**St Taemsrom Itde f: Hide HS Co
### Example
w It Works# 📋 Ho

#

---lds tootheir fieure ignfrows** to coments in **Click elelements
- -side eside-byr ws** foromn 2, 3, 4 colus
- **ayoutrid L

### 3️⃣ Gew previ in thely**s instant*See change *xes
- checkbon/off** with olds fie*Toggle *ields
-ure fo confignt** ty elemeck an **CliControl
-ete Field 2️⃣ Compl
### diately
y immeplanges ap* - ch updates*eal-times
- **R fieldcheckedhows - only ssettings** our field s yview respected
- **Preelect slement ishen no epreview** wive  lbar shows**Right sideation
- onfigurield Cith FPreview wLive 1️⃣ es

### 🎯 New Featur

## ``

---ilder-pro
`template-bu001/alhost:3ttp://loc
```
hess


## 🚀 Acc

---uration!onfigld cour fie respects ythat**  previewvelicomplete ows a ** sher now Pro Build
Thew
Ne## ✨ What's 
ew!
ve PreviTED with Li - UPDAr Proldeuimplate B🎨 Te# 