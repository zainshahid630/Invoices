-- ============================================
-- COPY AND PASTE THIS ENTIRE FILE INTO SUPABASE SQL EDITOR
-- ============================================

-- Create invoice_templates table
CREATE TABLE IF NOT EXISTS invoice_templates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  template_key VARCHAR(100) UNIQUE NOT NULL,
  preview_image_url TEXT,
  is_paid BOOLEAN DEFAULT false,
  price DECIMAL(10, 2) DEFAULT 0.00,
  is_active BOOLEAN DEFAULT true,
  display_order INTEGER DEFAULT 0,
  features JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create company_template_access table
CREATE TABLE IF NOT EXISTS company_template_access (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  template_id UUID REFERENCES invoice_templates(id) ON DELETE CASCADE,
  granted_by UUID REFERENCES super_admins(id),
  granted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  expires_at TIMESTAMP WITH TIME ZONE,
  is_active BOOLEAN DEFAULT true,
  UNIQUE(company_id, template_id)
);

-- Insert default templates (only if they don't exist)
INSERT INTO invoice_templates (name, description, template_key, is_paid, price, display_order, features)
SELECT 'Modern Template', 'Clean, contemporary design with blue gradient header. Perfect for tech companies and startups.', 'modern', false, 0.00, 1, '["Blue gradient header", "Modern typography", "Clean minimal design", "FBR logo & QR code", "Professional layout"]'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM invoice_templates WHERE template_key = 'modern');

INSERT INTO invoice_templates (name, description, template_key, is_paid, price, display_order, features)
SELECT 'Classic Template', 'Traditional, formal design with bold borders. Ideal for traditional businesses and law firms.', 'classic', false, 0.00, 2, '["Bold borders", "Serif typography", "Formal structured layout", "FBR logo & QR code", "Alternating row colors"]'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM invoice_templates WHERE template_key = 'classic');

INSERT INTO invoice_templates (name, description, template_key, is_paid, price, display_order, features)
SELECT 'Minimal Template', 'Ultra-clean minimalist design with maximum white space. For premium brands.', 'minimal', true, 499.00, 3, '["Minimalist design", "Maximum white space", "Premium typography", "FBR logo & QR code", "Elegant layout"]'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM invoice_templates WHERE template_key = 'minimal');

INSERT INTO invoice_templates (name, description, template_key, is_paid, price, display_order, features)
SELECT 'Corporate Template', 'Professional corporate design with company branding. Perfect for large enterprises.', 'corporate', true, 799.00, 4, '["Corporate branding", "Custom color schemes", "Logo integration", "FBR logo & QR code", "Multi-page support"]'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM invoice_templates WHERE template_key = 'corporate');

INSERT INTO invoice_templates (name, description, template_key, is_paid, price, display_order, features)
SELECT 'Creative Template', 'Bold, creative design with vibrant colors. Ideal for creative agencies and designers.', 'creative', true, 599.00, 5, '["Vibrant colors", "Creative layout", "Modern design", "FBR logo & QR code", "Unique styling"]'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM invoice_templates WHERE template_key = 'creative');

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_invoice_templates_active ON invoice_templates(is_active);
CREATE INDEX IF NOT EXISTS idx_invoice_templates_paid ON invoice_templates(is_paid);
CREATE INDEX IF NOT EXISTS idx_company_template_access_company ON company_template_access(company_id);
CREATE INDEX IF NOT EXISTS idx_company_template_access_template ON company_template_access(template_id);

-- Verify the data
SELECT * FROM invoice_templates ORDER BY display_order;

